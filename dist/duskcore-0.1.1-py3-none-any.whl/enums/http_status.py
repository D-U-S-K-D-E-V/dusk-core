from enum import IntEnum

class HTTPStatusEnum(IntEnum):
    SUCCESS = 1,
    FAILURE = 2