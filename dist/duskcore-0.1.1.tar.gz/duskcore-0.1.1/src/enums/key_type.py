from enum import IntEnum

class KeyTypeEnum(IntEnum):
    ENCRYPT = 0
    HMAC = 1